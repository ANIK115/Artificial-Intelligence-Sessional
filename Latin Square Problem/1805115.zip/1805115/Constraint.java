package base;

public interface Constraint {
    public boolean isConstraintSatisfied(Variable variable, int value);
}
